#include "loopqueue.h"

//创建空队
create_empty_loopqueue()
{
    loopqueue_t *q = NULL;
    q=(loopqueue_t *)malloc();
}